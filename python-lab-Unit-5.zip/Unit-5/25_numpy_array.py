#25 Create a NumPy array
import numpy as np

arr = np.array([10, 20, 30, 40, 50])
print("Array:", arr)
